#!/bin/bash

echo ""
echo " ======================================"
echo "  FitPulse - Fitness Tracker App"
echo " ======================================"
echo ""

if ! command -v node &> /dev/null; then
  echo " ERROR: Node.js is not installed!"
  echo " Please download from: https://nodejs.org"
  exit 1
fi

echo " Installing dependencies..."
npm install --silent

echo " Starting FitPulse..."
echo ""
echo " Open Chrome and go to: http://localhost:3000"
echo ""

# Open browser automatically
if [[ "$OSTYPE" == "darwin"* ]]; then
  open "http://localhost:3000" &
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
  xdg-open "http://localhost:3000" &
fi

node server.js
