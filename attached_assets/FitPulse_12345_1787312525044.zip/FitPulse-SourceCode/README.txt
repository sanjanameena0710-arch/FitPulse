╔══════════════════════════════════════════════════════╗
║           FitPulse - Fitness Tracker App             ║
║         Chrome mein chalane ke liye guide            ║
╚══════════════════════════════════════════════════════╝

ZAROORAT (Requirements):
──────────────────────────────────────────────────────
✅ Node.js (v18 ya usse upar)
   Download: https://nodejs.org  →  LTS version install karo

WINDOWS MEIN CHALANE KA TARIKA:
──────────────────────────────────────────────────────
1. Is folder mein "start.bat" file par double-click karo
2. Thodi der ruko jab tak "FitPulse running at..." dikhe
3. Chrome automatically khul jayega http://localhost:3000 par
   (Agar na khule to Chrome mein khud type karo: localhost:3000)

MAC / LINUX MEIN CHALANE KA TARIKA:
──────────────────────────────────────────────────────
1. Terminal kholo is folder mein
2. Ye command run karo:
      chmod +x start.sh && ./start.sh
3. Chrome mein jao: http://localhost:3000

MANUALLY CHALANE KA TARIKA (agar upar wala kaam na kare):
──────────────────────────────────────────────────────
1. Is folder mein terminal/command prompt kholo
2. Run karo:  npm install
3. Run karo:  node server.js
4. Chrome mein jao: http://localhost:3000

DEMO ACCOUNT:
──────────────────────────────────────────────────────
Email:    demo@fitpulse.app
Password: demo123

(Ya apna naya account bana sakte ho Register se)

APP KI FEATURES:
──────────────────────────────────────────────────────
🏠 Dashboard     - Stats, recent workouts, BMI calculator
💪 Workout       - Exercise library, workout plans
📈 Progress      - Charts, goals tracking
👤 Profile       - Edit profile, change email/password, logout

DATA STORAGE:
──────────────────────────────────────────────────────
App apna data "fitpulse.db" file mein save karta hai
(SQLite database - koi setup nahi chahiye)

APP BAND KARNA:
──────────────────────────────────────────────────────
Terminal mein Ctrl+C press karo

──────────────────────────────────────────────────────
FitPulse v1.0 | Built with Expo + Express + SQLite
