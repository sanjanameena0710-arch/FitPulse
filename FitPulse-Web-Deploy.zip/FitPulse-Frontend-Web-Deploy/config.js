window.__FITPULSE_CONFIG__ = { apiUrl: "https://your-backend.onrender.com/api" };
