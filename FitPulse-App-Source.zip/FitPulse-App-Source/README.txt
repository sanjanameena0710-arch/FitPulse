FITPULSE MOBILE APP — SOURCE CODE
==================================

Built with: Expo (React Native) + TypeScript

REQUIREMENTS:
- Node.js 18+
- pnpm (npm install -g pnpm) OR npm
- For Android build: Android Studio + JDK 17

INSTALL:
  cd FitPulse-App-Source
  pnpm install   (or: npm install)

RUN IN DEV MODE:
  pnpm start
  (Scan QR with Expo Go app on your phone)

BUILD APK (recommended via EAS):
  npm install -g eas-cli
  eas login
  eas build --platform android --profile preview

CUSTOMIZATION:
  - app.json — change app name, bundle id, icon
  - assets/images/icon.png — replace your logo
  - constants/colors.ts — change theme colors

DEMO LOGIN:
  Email: demo@fitpulse.app
  Password: demo123

100% offline — no backend, no API, no database server needed.
All data stored on device via AsyncStorage.
