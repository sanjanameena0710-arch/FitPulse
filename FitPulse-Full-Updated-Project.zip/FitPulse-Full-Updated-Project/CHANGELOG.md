# Changelog

## 2026-08-30

- Added browser/WebView real-time MediaPipe pose landmark overlay.
- Added smoothed neon full-body skeleton and joint markers.
- Added dynamic push-up chest and arm highlight lines.
- Added push-up form status and complete down-to-up rep counting.
- Added rep `+1` flash animation.
- Added selectable 10/20/30-minute or custom timer-based Active Workout task completion.
- Added PostgreSQL camera session storage and authenticated API endpoints.
- Added Render backend configuration and separate deployment instructions.
- Added runtime frontend API URL configuration via `config.js`.
- Added online WebView APK source package.
- Fixed remote change-email persistence.
- Fixed API workout save route and user ownership checks.
- Fixed generated Zod barrel duplicate export.
- Fixed Netlify registration getting stuck when the backend URL is still a placeholder.
- Added API timeout and safe local fallback while backend deployment is pending.
- Removed the Home screen floating play button.
- Added API security headers, authentication/API rate limits, stronger password hashing, token expiry, validation, and security tests.
