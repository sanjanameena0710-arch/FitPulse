FITPULSE WEB — Offline Standalone Version
==========================================

This is a 100% offline fitness tracking web app.
NO server required. NO database setup. NO internet needed
(after first load).

QUICK START:
1. Open index.html in any modern browser (Chrome/Safari/Firefox)
2. Login with demo account:
     Email: demo@fitpulse.app
     Password: demo123
   OR create your own account.

DEPLOY ONLINE (free):
- Netlify Drop: https://app.netlify.com/drop (drag this folder)
- Vercel: https://vercel.com (drag this folder)
- GitHub Pages: upload as repo
- Any static host (Hostinger, GoDaddy, etc.)

FILES:
- index.html  : Main HTML shell
- styles.css  : All styling
- db.js       : LocalStorage data layer (auto-seeds demo)
- app.js      : Main app router + UI

DATA STORAGE:
- All data lives in browser localStorage
- Photos stored as base64
- Export/Import via Profile → Export/Import Data

CAMERA FEATURE:
- Workout → AI Rep Counter
- Requires HTTPS for camera access (HTTP localhost OK)
- Browser will ask camera permission

Built with vanilla JavaScript. No build step. No dependencies.
